package com.capgemini.Lab13_2;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.TimerTask;
import java.util.Timer;

public class DisplayTimer extends TimerTask {

	public DisplayTimer() {
		// TODO Auto-generated constructor stub
	}

	@Override
	public void run() {
		DateFormat timeFormat = new SimpleDateFormat("HH:mm:ss");
		Calendar cal = Calendar.getInstance();
		System.out.println(timeFormat.format(cal.getTimeInMillis()));
	}

	public static void main(String[] args) throws InterruptedException {
		Timer timer = new Timer();
		TimerTask task = new DisplayTimer();
		timer.schedule(task, 0, 5000);
		Thread.sleep(15000);
		timer.cancel();
	}
}
