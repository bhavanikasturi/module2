DECLARE
	v_department Department.Department_Name%TYPE;
	v_employee Employee%ROWTYPE;
	
BEGIN
	
	SELECT *
	INTO v_employee
	FROM Employee
	WHERE Employee_name = &empname;
	
	SELECT Department_Name
	INTO v_department
	FROM Department
	WHERE Department_no = v_employee.Department_no;
	
	DBMS_OUTPUT.PUT_LINE(v_employee.Employee_no);
	DBMS_OUTPUT.PUT_LINE(v_employee.Employee_Name);
	DBMS_OUTPUT.PUT_LINE(v_employee.Job);
	DBMS_OUTPUT.PUT_LINE(v_employee.Hire_Date);
	DBMS_OUTPUT.PUT_LINE(v_employee.Salary);
	DBMS_OUTPUT.PUT_LINE(v_employee.Commission);
	DBMS_OUTPUT.PUT_LINE(v_employee.Department_no);
	DBMS_OUTPUT.PUT_LINE(v_department);


END;
/