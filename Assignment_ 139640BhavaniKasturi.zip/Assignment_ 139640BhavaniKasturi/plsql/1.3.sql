DECLARE
	v_employee 	Employee%ROWTYPE;
	CURSOR c_employee IS
		SELECT * FROM Employee WHERE Employee_no=7369;

BEGIN
	OPEN c_employee;
	
	LOOP
		FETCH c_employee INTO v_employee;
		EXIT WHEN c_employee%NOTFOUND;
		
		DBMS_OUTPUT.PUT_LINE(v_employee.Employee_no);
		DBMS_OUTPUT.PUT_LINE(v_employee.Employee_Name);
		DBMS_OUTPUT.PUT_LINE(v_employee.Job);
		DBMS_OUTPUT.PUT_LINE(v_employee.Hire_Date);
		DBMS_OUTPUT.PUT_LINE(v_employee.Salary);
		DBMS_OUTPUT.PUT_LINE(v_employee.Commission);
		DBMS_OUTPUT.PUT_LINE(v_employee.Department_no);
		
	END LOOP;
	
	CLOSE c_employee;
END;
/