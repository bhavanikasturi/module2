CREATE OR REPLACE PROCEDURE details(
	v_staff_code IN Staff_Master.Staff_Code%TYPE,
	v_updated_sal OUT NUMBER,
	v_errmsg OUT VARCHAR2
)

IS
	v_staff_sal Staff_Master.Staff_Sal%TYPE;
	v_time NUMBER;
	v_doj DATE;
	v_emp_no NUMBER;
	
	
BEGIN
	
	SELECT Staff_Sal
	INTO v_staff_sal
	FROM Staff_Master
	WHERE Staff_Code = v_staff_code;
	
	SELECT Hire_Date
	INTO v_doj
	FROM Employee
	WHERE Employee_no = v_emp_no;
	
		
	v_time := TO_CHAR(sysdate,'YYYY') - TO_CHAR(v_doj,'YYYY');
	
	IF v_time<2 THEN	
		v_updated_sal := v_staff_sal;
		
	ELSIF v_time>2 AND v_time<5 THEN
		v_updated_sal := v_staff_sal*.20;
		
	ELSE
		v_updated_sal := v_staff_sal*.25;
	END IF;
		
	INSERT INTO Staff_Master_Back VALUES(v_staff_sal,v_updated_sal);
	
EXCEPTION
	WHEN OTHERS THEN
		v_errmsg := SQLERRM;

END;
/
