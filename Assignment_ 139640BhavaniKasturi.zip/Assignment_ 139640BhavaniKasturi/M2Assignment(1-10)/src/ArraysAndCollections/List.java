package ArraysAndCollections;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;

public class List {

	public static void main(String[] args)
	{
	
		Scanner sc=new Scanner(System.in);
		 ArrayList<String> Product = new ArrayList<>();
		 for(int i = 0; i < 5; i++){
				Product.add(sc.nextLine());
			}
		 Collections.sort(Product);
		  for (String name : Product) {
              System.out.println(name);
  }
		  sc.close();
	}

}
