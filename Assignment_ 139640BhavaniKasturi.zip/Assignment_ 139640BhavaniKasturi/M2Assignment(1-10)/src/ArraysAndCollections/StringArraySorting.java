package ArraysAndCollections;

import java.util.Arrays;
import java.util.Scanner;

public class StringArraySorting {
 public static void main(String[] args)
 {
	 Scanner scan = new Scanner(System.in);

	    System.out.println("How many product names would you like to enter?");
	    int n = scan.nextInt(); //Ensures you take an integer
	    System.out.println("Enter the " + n + " product names: ");

	    String [] productnames = new String[n];
	    //store the names in an array
	    for (int i = 0; i < productnames.length; i++){
	        productnames[i] = scan.nextLine();
	        }
	    Arrays.sort(productnames);
        
        System.out.println("String array sorted (case insensitive)");
        //print sorted elements again
        for(int i=0; i < productnames.length; i++){
                System.out.println(productnames[i]);
        }
        scan.close();
 }
}
