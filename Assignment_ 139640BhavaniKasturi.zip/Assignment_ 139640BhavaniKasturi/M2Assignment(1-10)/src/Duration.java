import java.util.Scanner;
import java.text.*;
import java.util.*;

public class Duration {
	public static void main(String[] args) {
		
		SimpleDateFormat dateformat=new SimpleDateFormat("yyyy/MM/dd");
		System.out.print("Insert first date: ");
        Scanner s = new Scanner(System.in);
        String date1 = s.nextLine();
       long year,month,day;
        try
        {
        	Date newdate1=dateformat.parse(date1);
        	Date CurrDate=new Date();
        	
        	long diff=CurrDate.getTime()-newdate1.getTime();
        	long diffInDays=(int)((diff)/(1000*60*60*24));
        	System.out.println("Difference in days:");
        	year = diffInDays / 365;
            diffInDays = diffInDays % 365;
            System.out.println("No. of years:"+year);
            month = diffInDays / 30;
            diffInDays = diffInDays % 30;
            System.out.println("No. of months:"+month);
            day = diffInDays;
            System.out.println("No. of days:"+day);
        }
        catch(ParseException e)
        {
        	e.printStackTrace();
        }
        s.close();
	}
}