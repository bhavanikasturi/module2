import java.util.Scanner;


public class PersonDetails {
	public static void main(String[] args)
	{
	String fname;
    String lname;
    char gender;
    int age;
    float weight = 0;
    Scanner scInput=new Scanner(System.in);
    System.out.println("Enter person details:");
    System.out.println("Enter First Name:");
    fname=scInput.nextLine();
    System.out.println("Enter Last Name:");
    lname=scInput.nextLine();
    System.out.println("Enter Gender:");
    gender=scInput.next().charAt(0);
    scInput.nextLine();
    System.out.println("Enter age: ");
    age=scInput.nextInt();
    scInput.nextLine();
    System.out.println("Enter weight: ");
    weight=scInput.nextFloat();
    scInput.nextLine();
    scInput.close();
    System.out.println("person details:");
	System.out.println("_______________");
	System.out.println("FirstName: "+fname);
	System.out.println("LastNmae: "+lname);
	System.out.println("Gender: "+gender);
	System.out.println("Age "+age);
	System.out.println("Weight: "+weight);
}
}
