import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Scanner;
public class PersonMain {
	public static void main(String[] args)
    {
	String fname=new String();
    String lname=new String();
    char gender;
    String number=new String();
    String dob=new String();
    //String name=new String();
    Scanner scInput=new Scanner(System.in);
    System.out.println("Enter person details:");
    System.out.println("Enter First Name:");
    fname=scInput.nextLine();
    System.out.println("Enter Last Name:");
    lname=scInput.nextLine();
    System.out.println("Enter Gender:");
    gender=scInput.next().charAt(0);
    scInput.nextLine();
    System.out.println("Enter Phone Number:");
    number=scInput.nextLine();
    System.out.print("Insert first date: ");
    dob = scInput.nextLine();
    long age=calculateAge(dob);
    String fullname=getFullName(fname,lname);
    
    scInput.close();
    Person person1=new Person(fname,lname,gender,number,dob,age,fullname);
    person1.output();
    
    
    }

	private static String getFullName(String fname, String lname) {
		if(fname == null || fname.isEmpty()||lname == null || lname.isEmpty()){
	        throw new RuntimeException("fname or lname cannot be empty");

	    }
		StringBuilder sb = new StringBuilder(14);
		sb.append(fname).append(" ").append(lname);
		String name=sb.toString();
		return name;
	}

	private static long calculateAge(String dob) {
		SimpleDateFormat dateformat=new SimpleDateFormat("yyyy/MM/dd");
		try
        {
        	Date newdate1=dateformat.parse(dob);
        	Date CurrDate=new Date();
        	
        	
        	
        	long age=CurrDate.getYear()-newdate1.getYear();
        	if(age<15){
    	        throw new RuntimeException("Age shouble be greater than 15");

    	    }
        	else
        	{
        	return age;
        	}
       }
        catch(ParseException e)
        {
        	e.printStackTrace();
        }
		return 0;
		
	}
}
