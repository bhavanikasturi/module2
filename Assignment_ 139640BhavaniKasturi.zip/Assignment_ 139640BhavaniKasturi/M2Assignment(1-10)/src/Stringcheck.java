import java.util.Scanner;


public class Stringcheck {
      public static void main(String[] arr)
      {
    	  String str;
    	  Scanner scInput=new Scanner(System.in);
  		  System.out.println("Enter String:");
  	      str=scInput.nextLine();
  	    char[] characters = str.toCharArray();
  	 
  	  int length = characters.length;
  	  int i;
  	for ( i = 0; i < length; i++) 
  	{
        for (int j = i + 1; j < length; j++)
        {
            if (characters[i] > characters[j]) 
            {
                System.out.println("It is not a positive string");
                System.exit(1);
             }
            
                j--;
                length--;
         }
     }
  	if(i==length)
  	{
  		System.out.println("positive string");
  	}
  	scInput.close();
    }
  	     
   }


