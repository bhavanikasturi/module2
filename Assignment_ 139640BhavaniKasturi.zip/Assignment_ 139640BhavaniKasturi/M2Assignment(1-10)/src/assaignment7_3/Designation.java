package assaignment7_3;

public enum Designation {


	System_Associate,Programmer,Manager,Clerk
}


