package assaignment7_3;

public enum InsuranceScheme {

		SchemeA,SchemeB,SchemeC,NoScheme
	

}
