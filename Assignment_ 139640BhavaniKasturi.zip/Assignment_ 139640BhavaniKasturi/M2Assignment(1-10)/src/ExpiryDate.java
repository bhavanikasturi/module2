import java.util.Scanner;
import java.util.Calendar;

public class ExpiryDate {
public static void main(String[] args) {
		int i,j;
		Scanner s = new Scanner(System.in);
		
	Calendar now = Calendar.getInstance();
	   
    System.out.println("Current date : " + (now.get(Calendar.MONTH) + 1)
                        + "-"
                        + now.get(Calendar.DATE)
                        + "-"
                        + now.get(Calendar.YEAR));
    
    System.out.println("Enter number of years in warrantee period");
	j=s.nextInt();
	System.out.println("Enter number of months in warrantee period");
    i=s.nextInt();
    //add months to current date using Calendar.add method
    now.add(Calendar.MONTH,i);
    now.add(Calendar.YEAR,j);
   // System.out.println((now.get(Calendar.MONTH)));
    System.out.println("Expiry Date : " + (now.get(Calendar.MONTH)+i)
                        + "-"
                        + now.get(Calendar.DATE)
                        + "-"
                        + now.get(Calendar.YEAR));
 

	
    s.close();
	
	
	
	
}
}
