/*package Employee;

public class CurrentAccount extends Account {
	
	void SavingsAccount(long balance) {
		super(0L,0.0d);
	}
		public static void deposit(double balance,double amount) {

			double  newbalance;
			
			
			newbalance = balance + amount;
			System.out.println("your new balance is  " +newbalance);
		
		}
	}

*/
package Employee;

public class CurrentAccount extends Account {
      static long draftlimit = 25000;

	CurrentAccount(long balance) {
		super(0L, 0.0d);
	}
	
	public static void withdraw(double balance,double amount) {
		double  newbalance;
		
		
		if (amount < balance) {
			if(amount<=draftlimit)
			{
			newbalance = balance - amount;
			System.out.println("your new balance is  " +newbalance);
			}
			else
			{
				System.out.println("You cannot withdraw money more than draft limit of 25000/-");
			}
		} else {
			System.out.println("your balance is only " + balance
					+ "\n withdrawal is not possible");
		
		}
		
	}
}
