/**14.5: Write a method to calculate factorial of a number. 
 * Test this method using method reference feature. 
 * 
 */
package com.capgemini.Lab14_5;

import java.util.function.Function;

/**
 * @author 
 *
 */
public class Lab_14_5 {

	public static void main(String[] args) {
		Function<Integer, Integer> factorial = Factorial::fact;
		System.out.println("Factoral is : "+factorial.apply(5));

	}

}